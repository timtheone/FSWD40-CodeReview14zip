const $ = require('jquery');
global.$ = global.jQuery = $;
require('bootstrap');
require('popper.js');
